from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

@app.get("/")
def basic():
    return {'''HOLA HOMOSAPIENS
    WELCOME!!!'''}

@app.get("/about_us")
def basic():
    return {'''PIP INSTALL Rimzim Sanghvi 
    PIP INSTALL Jayadeep Reddy
    RIMZIM SANGHVI :
    SRN:PES2UG20CS273
    funfact: A very excited homosapien
    JAYADEEP REDDY:
    SRN:PES2UG20cs235
    funfact: Love Movies'''}

datamob = []
datatv = []
datacomputer = []
dataspeakers = []
datatab = []
datalap = []
datacam = []


class Mobile(BaseModel):
    company_name : str
    model_name : str
    prices : float

class Telivison(BaseModel):
    company_name : str
    model_name : str
    prices : float

class Computer_And_itsParts(BaseModel):
    company_name : str
    model_name : str
    prices : float


class Speakers(BaseModel):
    company_name : str
    model_name : str
    prices : float

class Tablet(BaseModel):
    company_name : str
    model_name : str
    prices : float

class Laptop(BaseModel):
    company_name : str
    model_name : str
    prices : float

class Camera(BaseModel):
    company_name : str
    model_name : str
    prices : float     


@app.get("/mobile")
def mobile_detail():
    return datamob


@app.get("/telivison")
def tv_detail():
    return datatv

@app.get("/computer")
def computer_detail():
    return datacomputer

@app.get("/speaker")
def speaker_detail():
    return dataspeakers

@app.get("/tablet")
def get_tablet():
    return datatab

@app.get("/laptop")
def get_laptop():
    return datalap

@app.get("/camera")
def get_camera():
    return datacam


@app.post("/mobile")
def mobile_buy(mobile:Mobile):
    datamob.append(mobile.dict())
    return datamob[-1]

@app.post("/telivison")
def tv_buy(telivison:Telivison):
    datatv.append(telivison.dict())
    return datatv[-1]

@app.post("/computer")
def computer_buy(computer:Computer_And_itsParts):
    datacomputer.append(computer.dict())
    return datacomputer[-1]

@app.post("/speaker")
def speaker_buy(speaker:Speakers):
    dataspeakers.append(speaker.dict())
    return dataspeakers[-1]

@app.post("/tablet")
def tablet_buy(tablet : Tablet):
    datatab.append(tablet.dict())
    return datatab[-1] 

@app.post("/laptop")
def laptop_buy(laptop : Laptop):
    datalap.append(laptop.dict())
    return datalap[-1]

@app.post("/camera")
def camera_buy(camera : Camera):
    datacam.append(camera.dict())
    return datacam[-1] 

@app.delete("/mobile")
def del_mobile():
    datamob.pop()
    return {"This data is not available!"}

@app.delete("/telivison")
def del_tv():
    datatv.pop()
    return {"This data is not available!"}

@app.delete("/computer")
def del_comp():
    datacomputer.pop()
    return {"This data is not available!"}

@app.delete("/speaker")
def del_speaker():
    dataspeakers.pop()
    return {"This data is not available!"}

@app.delete("/tablet")
def del_tab():
    datatab.pop()
    return {"This data is not available!"}

@app.delete("/laptop")
def del_lap():
    datalap.pop()
    return {"This data is not available!"}

@app.delete("/camera")
def del_cam():
    datacam.pop()
    return {"This data is not available!"}



